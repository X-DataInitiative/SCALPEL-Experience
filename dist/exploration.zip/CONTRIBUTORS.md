# Contributors

The _SCALPEL-Analysis_ package was initially implemented by researchers, developers, and PhD students at [CMAP](http://www.cmap.polytechnique.fr/?lang=en).

## List of Contributors

- Youcef Sebiat
- Maryan Morel
- Dinh Phong Nguyen