import json
from copy import copy
from typing import List

from src.exploration.core.io import get_logger
from .cohort import Cohort
from .metadata import Metadata


def metadata_from_flowchart(metadata: Metadata, flowchart_json: str) -> Metadata:
    flowchart_description = json.loads(flowchart_json)
    intermediate = flowchart_description[
        "intermediate_operations"
    ]  # type: Dict[str, Dict] # noqa：F821
    updated_metadata = copy(metadata)
    for (_, description) in intermediate.items():
        new_cohort = metadata.get_from_description(description)
        updated_metadata = updated_metadata.add_cohort(new_cohort.name, new_cohort)
    return updated_metadata


def get_steps(flowchart_json: str) -> List[str]:
    flowchart_description = json.loads(flowchart_json)
    return flowchart_description["steps"]


class Flowchart:
    """A Flowchart is a linear list of steps. The user inputs a list of cohorts (that
    stem from the Metadata of SNIIRAM-Featuring or built cohorts using intermediate
    cohorts in the flowchart json.
    It acts as the following:
    1. Takes the first cohort as the basic starting point.
    2. For all the remaining steps, it takes the n cohort and intersect it with the cohort
    n-1.
    """

    def __init__(self, steps: List[Cohort]):
        steps_length = len(steps)
        if steps_length == 0:
            get_logger().warning("You are initiating a en Empty Flowchart.")
        if steps_length == 1:
            self.steps = steps
        elif steps_length == 2:
            self.steps = [steps[0], steps[0].intersection(steps[1])]
        else:
            new_steps = [steps[0]]
            for step in steps[1:]:
                new_steps.append(new_steps[-1].intersection(step))
            self.steps = new_steps

    @staticmethod
    def from_json(metadata: Metadata, flowchart_json: str) -> "Flowchart":
        steps = get_steps(flowchart_json)  # type: List[str]
        metadata_flow_chart = metadata_from_flowchart(metadata, flowchart_json)
        new_metadata = metadata.union(metadata_flow_chart)  # type: Metadata
        return Flowchart([new_metadata.get(step) for step in steps])

    def create_flowchart(self, input: Cohort) -> "Flowchart":
        """
        Create a new Flowchart is pre-appended to the existing Flowchart.
        Parameters
        ----------
        input : Cohort to be pre-appended.

        Returns
        -------
        A new Flowchart object where the new first step is the input Cohort and the
        subsequent steps are the current steps.
        """
        new_steps = [input]
        new_steps.extend(self.steps)
        return Flowchart(new_steps)

    def __iter__(self):
        return iter(self.steps)
